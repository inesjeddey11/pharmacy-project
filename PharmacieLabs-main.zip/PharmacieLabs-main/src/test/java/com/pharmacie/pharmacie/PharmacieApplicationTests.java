package com.pharmacie.pharmacie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmacieApplicationTests {

	@Test
	void contextLoads() {
	}

}
